#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RElkins
# Date:  April, 29, 2019
# ChangeLog:
#   RElkins, 04/29/2019, Created dictionary program from RROOT template
#
#-------------------------------------------------#


# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
f = open("todo.txt","r") #opens file with name of "todo.txt"
lstTable = []
for line in f:
    lstTable.append(line)
print(lstTable)


# Step 2 - Display a menu of choices to the user
while True:
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line
# Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        for ObjRow in lstTable:
            print(ObjRow)
# Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        #get user data
        print('Please enter your new data, type EXIT once you are done')
        while True:
            strTask = input("Enter your task here: ") # input item
            if strTask.lower() == "exit": break # checks for exit command from loop
# process user data to file
            else: strPri = input("Enter the priority: ")
            dicNewRow = {"Task":strTask, "Priority":strPri}
            lstTable.append(dicNewRow)

# Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        DelItem = input("Enter a task to remove by index value starting at 0: ")
        print(lstTable)
        if DelItem in lstTable:
            del lstTable[int(DelItem)]
        print("You have removed the task,", DelItem, ", from the table.")
        print("The table now shows", lstTable)
        continue
# Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        useroption = input("Save? Y or N: ") #create option for user to save tuple data
        if useroption.lower() or useroption.strip() == "y": #allow for user error with spacing and case
            objFile = open("todo.txt", "a") #opens text file
            for row in lstTable:
                objFile.write(str(row) + "\n") #writes value to text file
        objFile.close() #closes text file
        if useroption.lower() == "y":
            print("Saved!")
        else:
            print("No data saved")
    elif (strChoice == '5'):
        break #and Exit the program

